AINDRILA'S LITTLE UNIVERSE — QUICK START

Files:
- aindrila_birthday_universe.html: complete standalone website.

How to use:
1. Download the HTML file.
2. Open it in a modern browser (Chrome is a good choice).
3. To share it as a website, upload the HTML file to a static host such as Netlify Drop or GitHub Pages, then send the published link over WhatsApp.

Included:
- Seven chapters.
- Swipe-created shooting stars and tap-to-connect custom constellations.
- Four Cosmic Garden planets with four mini-games and completion gates.
- Four memory orbs and seven collectible stars.
- Four three-option decisions that map to 81 distinct combinations of message sections.
- Copyable final birthday message, sound toggle, responsive layout, and reduced-motion support.

Important note:
The ending is composed from four choice-specific message sections. This gives 81 distinct combinations (3 x 3 x 3 x 3). If you want 81 individually hand-written full-length letters rather than distinct combinations of personalized sections, those can be authored as a separate content pass.

No backend or account is required. Progress is held in page memory and resets when the page is reloaded.
